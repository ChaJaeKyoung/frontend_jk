const gnb = document.querySelector('.gnb');
const navBg = document.querySelector('.nav-bg');
const subMenuEls = document.querySelectorAll('.nav li ul' )

console.log(subMenuEls);


gnb.addEventListener('mouseover',function() {
  navBg.classList.add('on');  
  subMenuEls.forEach(function (subMenuEl) {   
    // if (navBg.classList.contains('on')) {
      subMenuEl.classList.add('on');
    // } else {
    //   subMenuEl.classList.remove('on');
    // }
    console.log(subMenuEl);
    });
});
gnb.addEventListener('mouseout',function() {
  navBg.classList.remove('on');  
  subMenuEls.forEach(function (subMenuEl) {   
      subMenuEl.classList.remove('on');
  });


});








